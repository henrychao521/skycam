"""把中央氣象署臺北站（46692）最近 24 小時的逐 10 分鐘觀測存成每天一個 CSV，和照片放在一起對照。
長期紀錄要「寫下當時的狀況」：這支程式自動幫每一天記下天氣、氣溫、溼度、雨量與累積日照時數。
用法：python weather_log.py [輸出資料夾，預設 weather]
資料來源：中央氣象署觀測資料查詢 https://www.cwa.gov.tw/V8/C/W/OBS_Station.html?ID=46692
"""
import csv, html, os, re, sys, urllib.request, datetime as dt

URL = "https://www.cwa.gov.tw/V8/C/W/Observe/MOD/24hr/46692.html"
FIELDS = ["date", "time", "weather", "temp_c", "humidity", "rain_mm", "sunshine_hr", "visibility_km", "pressure_hpa"]


def fetch():
    req = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://www.cwa.gov.tw/V8/C/W/OBS_Station.html?ID=46692"})
    return urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "replace")


def parse(page, year=None):
    year = year or dt.date.today().year; rows = []
    for tr in re.findall(r"<tr.*?</tr>", page, flags=re.S):
        cells = dict(re.findall(r'<t[hd][^>]*headers="([^" ]+)[^"]*"[^>]*>(.*?)</t[hd]>', tr, flags=re.S))
        m = re.search(r"(\d\d)/(\d\d)\s*(?:<br[^>]*>)?\s*(\d\d:\d\d)", tr)
        if not m or "temp" not in cells: continue
        txt = lambda k: re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", cells.get(k, "")))).strip()
        w = re.search(r'(?:alt|title)="([^"]*)"', cells.get("weather", "")); temp = re.search(r"-?\d+(?:\.\d+)?", txt("temp"))
        rows.append(dict(date=f"{year}{m.group(1)}{m.group(2)}", time=m.group(3), weather=(w.group(1) if w else txt("weather")),
                         temp_c=temp.group(0) if temp else "", humidity=txt("hum"), rain_mm=txt("rain"), sunshine_hr=txt("sunlight"),
                         visibility_km=txt("visible-1"), pressure_hpa=txt("pre")))
    return rows


def save(rows, out_dir):
    os.makedirs(out_dir, exist_ok=True); days = {}
    for r in rows: days.setdefault(r["date"], {})[r["time"]] = r
    for day, new in days.items():
        path = os.path.join(out_dir, f"{day}_weather.csv"); old = {}
        if os.path.exists(path):
            with open(path, encoding="utf-8-sig") as f: old = {r["time"]: r for r in csv.DictReader(f)}
        old.update(new)                                                   # 同一時刻以新抓到的為準，舊的時刻保留
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=FIELDS); w.writeheader(); [w.writerow(old[t]) for t in sorted(old)]
    return sorted(days)


def summary(out_dir, day, t0="15:00", t1="18:00"):
    path = os.path.join(out_dir, f"{day}_weather.csv")
    if not os.path.exists(path): return f"{day}：沒有天氣資料"
    with open(path, encoding="utf-8-sig") as f: rows = list(csv.DictReader(f))
    from collections import Counter
    allw = Counter(r["weather"] for r in rows if r["weather"]); sub = Counter(r["weather"] for r in rows if t0 <= r["time"] <= t1 and r["weather"])
    last = rows[-1]
    return (f"{day}：整天 {dict(allw.most_common())}；{t0}～{t1} {dict(sub.most_common()) or '尚無資料'}；"
            f"最後一筆 {last['time']} {last['weather']} {last['temp_c']}°C、累積日照 {last['sunshine_hr']} 小時、雨量 {last['rain_mm']} 毫米")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "weather"
    for d in save(parse(fetch()), out): print(summary(out, d))
