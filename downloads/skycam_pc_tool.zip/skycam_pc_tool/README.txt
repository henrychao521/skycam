天空日記相機 電腦端工具（Python 3.10 以上）

安裝：pip install numpy pillow   （要做縮時影片另外安裝 ffmpeg）
抓照片：python skycam_tool.py pull http://skycam.local --out photos
分析：  python skycam_tool.py analyze --photos photos --out analysis
每一天會產生：資料表 csv、太陽軌跡圖、天空色條、縮時影片。

fake_skycam.py 是「假相機」：沒有板子時可以用它產生合成照片來練習（python fake_skycam.py 8765，再 pull http://127.0.0.1:8765）。
