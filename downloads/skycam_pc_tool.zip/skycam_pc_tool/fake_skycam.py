"""假的天空日記相機：用和韌體相同的網址介面回傳合成照片，給電腦端程式測試用（太陽位置是已知的，可以對答案）。
用法：python fake_skycam.py [port]     預設 8765
"""
import io, json, re, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from PIL import Image, ImageDraw
import numpy as np

W, H, HORIZON = 1600, 1200, 900
DAYS = ["20261127", "20261128", "20261129"]


def truth(day, mn):
    """回傳 (看得到太陽嗎, x, y)。mn＝一天中的第幾分鐘。每天往右移 3 像素。"""
    k = mn - 16 * 60
    x = 300 + 5.0 * k + 3.0 * DAYS.index(day); y = 200 + 6.5 * k
    return (0 <= k <= 120 and y < HORIZON - 14), x, y


def names(day):
    out = []
    for mn in range(5 * 60, 19 * 60 + 1):
        focus = 16 * 60 <= mn <= 18 * 60
        if focus or mn % 10 == 0:
            hms = f"{mn // 60:02d}{mn % 60:02d}0{DAYS.index(day)}"          # 秒數故意不是 00
            out.append(hms + ".jpg")
            if focus: out.append(hms + "_d.jpg")
    return sorted(out)


def render(day, name):
    mn = int(name[:2]) * 60 + int(name[2:4]); dark = name.endswith("_d.jpg")
    vis, x, y = truth(day, mn)
    if dark:
        im = Image.new("RGB", (W, H), (5, 5, 8)); d = ImageDraw.Draw(im)
        if vis: d.ellipse((x - 14, y - 14, x + 14, y + 14), fill=(255, 255, 250))
        d.rectangle((1500, 1100, 1506, 1104), fill=(230, 230, 230))            # 一小塊雜訊亮點（面積小，不能被當成太陽）
    else:
        t = min(1.0, max(0.0, (mn - 15 * 60) / 180))                           # 15:00→18:00 由藍變橘再變暗
        top = np.array([70, 140, 230]) * (1 - t) + np.array([40, 30, 70]) * t
        bot = np.array([170, 210, 250]) * (1 - t) + np.array([250, 140, 60]) * t
        if mn > 17 * 60 + 50: top, bot = top * 0.35, bot * 0.35
        g = np.linspace(0, 1, HORIZON)[:, None, None]
        sky = (top[None, None, :] * (1 - g) + bot[None, None, :] * g).repeat(W, axis=1)
        arr = np.zeros((H, W, 3)); arr[:HORIZON] = sky; arr[HORIZON:] = (30, 35, 30)
        im = Image.fromarray(arr.clip(0, 255).astype("uint8")); d = ImageDraw.Draw(im)
        if vis: d.ellipse((x - 60, y - 60, x + 60, y + 60), fill=(255, 255, 255))
    b = io.BytesIO(); im.save(b, "JPEG", quality=85); return b.getvalue()


class Hd(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def send(self, code, ctype, body):
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        J = lambda o, code=200: self.send(code, "application/json; charset=utf-8", json.dumps(o).encode())
        if u.path == "/status":
            return J(dict(fw="fake", time="2026-11-29 18:30:00", synced=True, uptime_s=1, ip="127.0.0.1", rssi=-50, sd_ok=True, sd_total_mb=30000,
                          sd_used_mb=100, shots_today=1, shots_total=1, last_file="", last_error="", sensor_pid=0x26, free_heap=1, free_psram=1))
        if u.path == "/days": return J(DAYS)
        day, name = q.get("day", ""), q.get("name", "")
        if u.path == "/list":
            if not re.fullmatch(r"\d{8}", day): return self.send(400, "text/plain", b"bad day")
            return J([{"name": n, "size": len(render(day, n))} for n in names(day)] if day in DAYS else [])
        if u.path == "/photo":
            if not re.fullmatch(r"\d{8}", day) or not re.fullmatch(r"\d{6}(_d)?\.jpg", name): return self.send(400, "text/plain", b"bad")
            if day not in DAYS or name not in names(day): return self.send(404, "text/plain", b"no")
            return self.send(200, "image/jpeg", render(day, name))
        if u.path == "/capture": return self.send(200, "image/jpeg", render(DAYS[-1], "170000_d.jpg" if q.get("dark") == "1" else "170000.jpg"))
        self.send(404, "text/plain", b"not found")


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    ThreadingHTTPServer(("127.0.0.1", port), Hd).serve_forever()
