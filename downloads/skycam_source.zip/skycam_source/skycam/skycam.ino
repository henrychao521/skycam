#include <WiFi.h>
#include <ESPmDNS.h>
#include <esp_camera.h>
#include <esp_http_server.h>
#include <FS.h>
#include <SD.h>
#include <SPI.h>
#include <time.h>
#include <esp_sntp.h>
#include <Preferences.h>
#include <DNSServer.h>
#include <ArduinoOTA.h>
#include <Update.h>

#include "improv.h"
#include <esp_wifi.h>

#if __has_include("secrets.h")
#include "secrets.h"
#endif
#ifndef WIFI_SSID
#define WIFI_SSID ""
#define WIFI_PASS ""
#endif

// ============================================================================
// 1. 設定區（學生與家長主要修改這一段）
// ============================================================================

const char *FW_VERSION = "1.1.1";

// 拍照時間表（單位：一天中的第幾分鐘，0 代表 00:00，1439 代表 23:59）
const int DAY_START_MIN   = 5 * 60;        // 05:00 開始
const int DAY_END_MIN     = 19 * 60;       // 19:00 結束（含）
const int DAY_INTERVAL    = 10;            // 白天每 10 分鐘一張
const int FOCUS_START_MIN = 16 * 60;       // 16:00～18:00 是「重點時段」（日落前後）
const int FOCUS_END_MIN   = 18 * 60;
const int FOCUS_INTERVAL  = 1;             // 重點時段每 1 分鐘一張
const bool FOCUS_DARK     = true;          // 重點時段每次多拍一張暗曝光

// 相機參數設定（預設值，之後可在 /config 遠端調整並保存）
const int JPEG_QUALITY    = 10;            // JPEG 畫質（數字越小畫質越好、檔案越大，建議 10～15）
const int DARK_AEC        = 20;            // 暗曝光快門值（拍太陽用，數字越小越暗）
const bool FLIP_180       = false;         // 機身倒著裝時改成 true，畫面會旋轉 180 度

// 主機、網路與 OTA 設定
const char *MDNS_HOST     = "skycam";      // 瀏覽器可輸入 http://skycam.local
const char *TZ_INFO       = "CST-8";       // 台灣時間 UTC+8
const char *OTA_PASSWORD  = "";            // 留空＝不檢查；填了之後兩種更新方式（ArduinoOTA 與網頁更新）都要輸入

// 硬體腳位設定（Seeed Studio XIAO ESP32-S3 Sense 固定腳位，請勿修改）
// 一般模式下 GPIO21 為 SD 卡 CS 腳；設定模式未掛載 SD 卡時，GPIO21 作為板上橘色狀態燈（低電位亮）
const int SD_CS_PIN       = 21;
const int CAM_PIN_PWDN    = -1;
const int CAM_PIN_RESET   = -1;
const int CAM_PIN_XCLK    = 10;
const int CAM_PIN_SIOD    = 40;
const int CAM_PIN_SIOC    = 39;
const int CAM_PIN_Y9      = 48;
const int CAM_PIN_Y8      = 11;
const int CAM_PIN_Y7      = 12;
const int CAM_PIN_Y6      = 14;
const int CAM_PIN_Y5      = 16;
const int CAM_PIN_Y4      = 18;
const int CAM_PIN_Y3      = 17;
const int CAM_PIN_Y2      = 15;
const int CAM_PIN_VSYNC   = 38;
const int CAM_PIN_HREF    = 47;
const int CAM_PIN_PCLK    = 13;

// ============================================================================
// 2. 全域狀態與保護鎖
// ============================================================================

enum RunMode { MODE_NORMAL, MODE_SETUP };

struct ScannedNet {
  String ssid;
  int32_t rssi;
  bool encrypted;
};

RunMode runMode = MODE_NORMAL;

SemaphoreHandle_t cameraMutex = nullptr;
SemaphoreHandle_t sdMutex     = nullptr;
SemaphoreHandle_t stateMutex  = nullptr;

// 保存在板子裡的設定（由 Preferences 載入）
String wifiSsid;
String wifiPass;
bool hasSavedWifi = false;
bool cfgFlip180   = FLIP_180;
int cfgDarkAec    = DARK_AEC;

// 設定模式專用狀態
String apSsid;
DNSServer dnsServer;
std::vector<ScannedNet> scannedNets;
bool bgRetryActive = false;
unsigned long lastBgRetryStartMs = 0;
unsigned long bgRetryBeginMs = 0;

// 硬體與系統狀態
bool cameraOk = false;
int sensorPid = 0;

volatile bool sdOk = false;
unsigned long lastSdRetryMs = 0;

bool mdnsStarted = false;
bool otaStarted = false;
volatile bool otaBusy = false;

bool wasWifiConnected = false;
unsigned long wifiDisconnectSinceMs = 0;
unsigned long lastWifiReconnectMs = 0;

unsigned long lastNtpWarnMs = 0;
unsigned long lastScheduleCheckMs = 0;
int64_t lastShotMinuteKey = -1;

int currentDayKey = 0;
int shotsToday = 0;
int shotsTotal = 0;
char lastFile[48] = "";
char lastError[128] = "";

volatile unsigned long restartAtMs = 0;

httpd_handle_t httpServer = nullptr;

// 預約在指定毫秒後重新啟動（避免在網頁回應過程中直接重啟）
void scheduleRestart(unsigned long delayMs) {
  unsigned long target = millis() + delayMs;
  if (target == 0) {
    target = 1;  // 0 代表沒有排定重啟
  }
  restartAtMs = target;
}

void checkPendingRestart() {
  unsigned long target = restartAtMs;
  if (target != 0 && (int32_t)(millis() - target) >= 0) {
    restartAtMs = 0;
    Serial.println("正在重新啟動相機...");
    Serial.flush();
    delay(50);
    ESP.restart();
  }
}

// 記錄最近一次錯誤訊息（執行緒安全）
void setLastError(const char *msg) {
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    snprintf(lastError, sizeof(lastError), "%s", msg ? msg : "");
    xSemaphoreGive(stateMutex);
  } else {
    snprintf(lastError, sizeof(lastError), "%s", msg ? msg : "");
  }
}

// 記錄拍照成功後的檔案與計數
void recordShotSuccess(int dayKey, const char *savedPath) {
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    if (dayKey > 0 && dayKey != currentDayKey) {
      currentDayKey = dayKey;
      shotsToday = 0;
    }
    shotsToday++;
    shotsTotal++;
    if (savedPath != nullptr) {
      snprintf(lastFile, sizeof(lastFile), "%s", savedPath);
    }
    xSemaphoreGive(stateMutex);
  }
}

// ============================================================================
// 3. 板載設定存取（Preferences）
// ============================================================================

bool isPlaceholderSsid(const char *s) {
  if (s == nullptr || s[0] == '\0') {
    return true;
  }
  return (strcmp(s, "your-wifi") == 0) || (strcmp(s, "你的Wi-Fi名稱") == 0);
}

void loadSettings() {
  bool hasKeySsid = false;
  String storedSsid;
  String storedPass;
  bool storedFlip = FLIP_180;
  int storedDaec = DARK_AEC;

  Preferences prefs;
  if (prefs.begin("skycam", true)) {
    if (prefs.isKey("ssid")) {
      hasKeySsid = true;
      storedSsid = prefs.getString("ssid", "");
      storedPass = prefs.getString("pass", "");
    }
    storedFlip = prefs.getBool("flip", FLIP_180);
    storedDaec = prefs.getInt("daec", DARK_AEC);
    prefs.end();
  }

  if (!hasKeySsid) {
    // 板子尚未保存過帳密時，改讀 secrets.h 當作初始值
    if (!isPlaceholderSsid(WIFI_SSID)) {
      storedSsid = String(WIFI_SSID);
      storedPass = String(WIFI_PASS);
    }
  }

  if (storedDaec < 1 || storedDaec > 1200) {
    storedDaec = DARK_AEC;
  }

  wifiSsid = storedSsid;
  wifiPass = storedPass;
  hasSavedWifi = (wifiSsid.length() > 0);
  cfgFlip180 = storedFlip;
  cfgDarkAec = storedDaec;
}

bool saveWifiSettings(const String &ssid, const String &pass) {
  Preferences prefs;
  if (!prefs.begin("skycam", false)) {
    return false;
  }
  prefs.putString("ssid", ssid);
  prefs.putString("pass", pass);
  prefs.end();

  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    wifiSsid = ssid;
    wifiPass = pass;
    hasSavedWifi = (wifiSsid.length() > 0);
    xSemaphoreGive(stateMutex);
  } else {
    wifiSsid = ssid;
    wifiPass = pass;
    hasSavedWifi = (wifiSsid.length() > 0);
  }
  return true;
}

// Wi-Fi 發射功率（dBm，2～20）。小板子在功率開到最大時，供電或天線可能撐不住，
// 反而讓大一點的資料（照片）傳不出去；調低一些通常比較穩。可用 /config?txpower=數值 遠端調整。
const int TX_POWER_DEFAULT = 15;
volatile int cfgTxPower = TX_POWER_DEFAULT;

void loadTxPower() {
  Preferences prefs;
  if (prefs.begin("skycam", true)) {
    int v = prefs.getInt("txp", TX_POWER_DEFAULT);
    if (v >= 2 && v <= 20) {
      cfgTxPower = v;
    }
    prefs.end();
  }
}

void saveTxPower(int dbm) {
  Preferences prefs;
  if (prefs.begin("skycam", false)) {
    prefs.putInt("txp", dbm);
    prefs.end();
  }
}

// 套用發射功率（單位是 0.25 dBm）。要在 Wi-Fi 啟動之後呼叫才有效。
void applyTxPower() {
  esp_wifi_set_max_tx_power((int8_t)(cfgTxPower * 4));
}

bool saveCameraSettings(bool flip, int darkAec) {
  Preferences prefs;
  if (!prefs.begin("skycam", false)) {
    return false;
  }
  prefs.putBool("flip", flip);
  prefs.putInt("daec", darkAec);
  prefs.end();
  return true;
}

// ============================================================================
// 4. 鏡頭初始化與拍照
// ============================================================================

// 套用上下翻轉與左右鏡像（OV3660 基準為 vflip=1、hmirror=0；其餘為 0、0）
void applySensorFlip(sensor_t *s, bool flip) {
  if (s == nullptr) {
    return;
  }
  int baseVflip = (s->id.PID == OV3660_PID) ? 1 : 0;
  int baseHmirror = 0;
  s->set_vflip(s, flip ? (baseVflip ? 0 : 1) : baseVflip);
  s->set_hmirror(s, flip ? (baseHmirror ? 0 : 1) : baseHmirror);
}

bool initCamera() {
  if (!psramFound()) {
    Serial.println("請到 工具 > PSRAM 選 OPI PSRAM");
    while (true) {
      delay(1000);
    }
  }

  camera_config_t config = {};
  config.pin_pwdn     = CAM_PIN_PWDN;
  config.pin_reset    = CAM_PIN_RESET;
  config.pin_xclk     = CAM_PIN_XCLK;
  config.pin_sccb_sda = CAM_PIN_SIOD;
  config.pin_sccb_scl = CAM_PIN_SIOC;
  config.pin_d7       = CAM_PIN_Y9;
  config.pin_d6       = CAM_PIN_Y8;
  config.pin_d5       = CAM_PIN_Y7;
  config.pin_d4       = CAM_PIN_Y6;
  config.pin_d3       = CAM_PIN_Y5;
  config.pin_d2       = CAM_PIN_Y4;
  config.pin_d1       = CAM_PIN_Y3;
  config.pin_d0       = CAM_PIN_Y2;
  config.pin_vsync    = CAM_PIN_VSYNC;
  config.pin_href     = CAM_PIN_HREF;
  config.pin_pclk     = CAM_PIN_PCLK;

  config.xclk_freq_hz = 20000000;
  config.ledc_timer   = LEDC_TIMER_0;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size   = FRAMESIZE_UXGA;
  config.jpeg_quality = JPEG_QUALITY;
  config.fb_count     = 1;
  config.fb_location  = CAMERA_FB_IN_PSRAM;
  config.grab_mode    = CAMERA_GRAB_WHEN_EMPTY;

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    char msg[64];
    snprintf(msg, sizeof(msg), "鏡頭初始化失敗 (0x%x)", (unsigned)err);
    Serial.println(msg);
    setLastError(msg);
    return false;
  }

  sensor_t *s = esp_camera_sensor_get();
  if (s != nullptr) {
    sensorPid = s->id.PID;
    if (s->id.PID == OV3660_PID) {
      s->set_brightness(s, 1);
      s->set_saturation(s, -2);
    }
    applySensorFlip(s, cfgFlip180);
  }

  Serial.printf("鏡頭初始化完成（感測器 PID: 0x%04x）\n", (unsigned)sensorPid);
  return true;
}

// 拍照並複製到 PSRAM 緩衝區（呼叫端使用完畢須自行 free(*outBuf)）
bool takePhoto(bool dark, uint8_t **outBuf, size_t *outLen) {
  if (!cameraOk) {
    setLastError("鏡頭尚未就緒");
    return false;
  }
  if (cameraMutex == nullptr || xSemaphoreTake(cameraMutex, pdMS_TO_TICKS(5000)) != pdTRUE) {
    setLastError("鏡頭忙碌逾時（超過 5 秒）");
    return false;
  }

  sensor_t *s = esp_camera_sensor_get();
  if (s == nullptr) {
    xSemaphoreGive(cameraMutex);
    setLastError("無法取得鏡頭感測器");
    return false;
  }

  int darkAecVal = cfgDarkAec;
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    darkAecVal = cfgDarkAec;
    xSemaphoreGive(stateMutex);
  }

  if (dark) {
    // 暗曝光：關閉自動曝光與自動增益，改用固定低曝光值
    s->set_exposure_ctrl(s, 0);
    s->set_gain_ctrl(s, 0);
    s->set_agc_gain(s, 0);
    s->set_aec_value(s, darkAecVal);

    for (int i = 0; i < 3; i++) {
      camera_fb_t *drop = esp_camera_fb_get();
      if (drop != nullptr) {
        esp_camera_fb_return(drop);
      }
    }
  } else {
    // 一般自動曝光：先丟掉 2 張讓曝光穩定並清掉舊畫面
    for (int i = 0; i < 2; i++) {
      camera_fb_t *drop = esp_camera_fb_get();
      if (drop != nullptr) {
        esp_camera_fb_return(drop);
      }
    }
  }

  camera_fb_t *fb = esp_camera_fb_get();

  // 無論成功或失敗，暗曝光拍完一定要恢復自動曝光與自動增益
  if (dark) {
    s->set_exposure_ctrl(s, 1);
    s->set_gain_ctrl(s, 1);
  }

  if (fb == nullptr) {
    xSemaphoreGive(cameraMutex);
    setLastError("拍照失敗（無法取得畫面）");
    return false;
  }

  uint8_t *copyBuf = (uint8_t *)ps_malloc(fb->len);
  if (copyBuf == nullptr) {
    esp_camera_fb_return(fb);
    xSemaphoreGive(cameraMutex);
    setLastError("PSRAM 空間不足，無法複製相片");
    return false;
  }

  memcpy(copyBuf, fb->buf, fb->len);
  *outBuf = copyBuf;
  *outLen = fb->len;

  esp_camera_fb_return(fb);
  xSemaphoreGive(cameraMutex);
  return true;
}

// ============================================================================
// 5. SD 卡管理與存檔
// ============================================================================

bool initSDInternal() {
  SD.end();
  if (!SD.begin(SD_CS_PIN)) {
    return false;
  }
  if (SD.cardType() == CARD_NONE) {
    SD.end();
    return false;
  }
  return true;
}

void initSD() {
  if (sdMutex != nullptr && xSemaphoreTake(sdMutex, pdMS_TO_TICKS(5000)) == pdTRUE) {
    sdOk = initSDInternal();
    xSemaphoreGive(sdMutex);
  } else {
    sdOk = initSDInternal();
  }

  if (sdOk) {
    Serial.println("SD 卡掛載成功");
  } else {
    Serial.println("找不到 SD 卡，稍後將每 60 秒自動重試");
    setLastError("SD 卡初始化失敗");
  }
}

void retrySDIfNeeded() {
  if (sdOk) {
    return;
  }
  unsigned long nowMs = millis();
  if (nowMs - lastSdRetryMs < 60000) {
    return;
  }
  lastSdRetryMs = nowMs;

  if (sdMutex != nullptr && xSemaphoreTake(sdMutex, pdMS_TO_TICKS(2000)) == pdTRUE) {
    sdOk = initSDInternal();
    xSemaphoreGive(sdMutex);
    if (sdOk) {
      Serial.println("SD 卡重新掛載成功");
    }
  }
}

bool savePhotoToSD(const char *dayStr, const char *fileName, const uint8_t *buf, size_t len,
                   char *outPath, size_t outPathSize) {
  if (!sdOk) {
    return false;
  }
  // 電腦正在下載照片時會占用 SD 卡，這裡最多等 15 秒
  if (sdMutex == nullptr || xSemaphoreTake(sdMutex, pdMS_TO_TICKS(15000)) != pdTRUE) {
    setLastError("SD 卡存取逾時");
    return false;
  }
  if (!sdOk) {
    xSemaphoreGive(sdMutex);
    return false;
  }

  char dirPath[32];
  snprintf(dirPath, sizeof(dirPath), "/%s", dayStr);
  if (!SD.exists(dirPath)) {
    if (!SD.mkdir(dirPath)) {
      sdOk = false;
      xSemaphoreGive(sdMutex);
      setLastError("無法建立日期資料夾");
      return false;
    }
  }

  char fullPath[80];
  snprintf(fullPath, sizeof(fullPath), "/%s/%s", dayStr, fileName);

  File file = SD.open(fullPath, FILE_WRITE);
  if (!file) {
    sdOk = false;
    xSemaphoreGive(sdMutex);
    setLastError("無法開啟 SD 卡檔案寫入");
    return false;
  }

  size_t written = file.write(buf, len);
  file.close();

  if (written != len) {
    SD.remove(fullPath);
    xSemaphoreGive(sdMutex);
    setLastError("SD 卡寫入不完整，已刪除損壞檔案");
    return false;
  }

  xSemaphoreGive(sdMutex);

  if (outPath != nullptr && outPathSize > 0) {
    snprintf(outPath, outPathSize, "%s", fullPath);
  }
  return true;
}

// ============================================================================
// 6. 時間同步與格式化
// ============================================================================

void initTime() {
  configTzTime(TZ_INFO, "time.stdtime.gov.tw", "pool.ntp.org", "time.google.com");
}

bool isTimeSynced() {
  return time(nullptr) > 1700000000;
}

bool getLocalTimeNow(struct tm *outTm) {
  if (!isTimeSynced()) {
    return false;
  }
  time_t now = time(nullptr);
  localtime_r(&now, outTm);
  return true;
}

void formatDayAndClock(const struct tm &t, char *dayBuf, size_t daySize,
                       char *clockBuf, size_t clockSize, int *outDayKey) {
  int year  = t.tm_year + 1900;
  int month = t.tm_mon + 1;
  int day   = t.tm_mday;
  snprintf(dayBuf, daySize, "%04d%02d%02d", year, month, day);
  snprintf(clockBuf, clockSize, "%02d%02d%02d", t.tm_hour, t.tm_min, t.tm_sec);
  if (outDayKey != nullptr) {
    *outDayKey = year * 10000 + month * 100 + day;
  }
}

// ============================================================================
// 7. 排程邏輯（純函式 + 排程執行）
// ============================================================================

bool inFocus(int minuteOfDay) {
  return minuteOfDay >= FOCUS_START_MIN && minuteOfDay <= FOCUS_END_MIN;
}

bool shouldShoot(int minuteOfDay) {
  if (minuteOfDay >= FOCUS_START_MIN && minuteOfDay <= FOCUS_END_MIN) {
    return (FOCUS_INTERVAL > 0) && (minuteOfDay % FOCUS_INTERVAL == 0);
  }
  if (minuteOfDay >= DAY_START_MIN && minuteOfDay <= DAY_END_MIN) {
    return (DAY_INTERVAL > 0) && (minuteOfDay % DAY_INTERVAL == 0);
  }
  return false;
}

// 拍攝並儲存一張照片到 SD 卡（正常與暗曝光共用流程）
bool captureAndSave(const char *dayStr, const char *fileName, int dayKey, bool dark) {
  uint8_t *jpgBuf = nullptr;
  size_t jpgLen = 0;
  if (!takePhoto(dark, &jpgBuf, &jpgLen)) {
    return false;
  }

  char savedPath[48] = "";
  bool ok = savePhotoToSD(dayStr, fileName, jpgBuf, jpgLen, savedPath, sizeof(savedPath));
  free(jpgBuf);

  if (ok) {
    recordShotSuccess(dayKey, savedPath);
    Serial.printf("已存檔：%s（%u 位元組）\n", savedPath, (unsigned)jpgLen);
  }
  return ok;
}

void runScheduler() {
  unsigned long nowMs = millis();
  if (nowMs - lastScheduleCheckMs < 200) {
    return;
  }
  lastScheduleCheckMs = nowMs;

  struct tm t = {};
  if (!getLocalTimeNow(&t)) {
    if (nowMs - lastNtpWarnMs >= 10000) {
      lastNtpWarnMs = nowMs;
      Serial.println("等待網路校時中（尚未同步時間，暫停自動排程）...");
    }
    return;
  }

  int dayKey = (t.tm_year + 1900) * 10000 + (t.tm_mon + 1) * 100 + t.tm_mday;
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    if (dayKey != currentDayKey) {
      currentDayKey = dayKey;
      shotsToday = 0;
    }
    xSemaphoreGive(stateMutex);
  }

  int64_t minuteKey = (int64_t)dayKey * 10000LL + (int64_t)t.tm_hour * 100LL + (int64_t)t.tm_min;
  if (minuteKey == lastShotMinuteKey) {
    return;
  }

  int minuteOfDay = t.tm_hour * 60 + t.tm_min;
  if (!shouldShoot(minuteOfDay)) {
    return;
  }

  // 同一分鐘只觸發一次，即使沒有 SD 卡也記錄已檢查該分鐘
  lastShotMinuteKey = minuteKey;

  if (!sdOk) {
    Serial.println("排程時間到，但目前沒有 SD 卡，跳過拍照");
    return;
  }

  char dayStr[48];
  char clockStr[48];
  formatDayAndClock(t, dayStr, sizeof(dayStr), clockStr, sizeof(clockStr), nullptr);

  char normalName[64];
  snprintf(normalName, sizeof(normalName), "%s.jpg", clockStr);
  captureAndSave(dayStr, normalName, dayKey, false);

  if (FOCUS_DARK && inFocus(minuteOfDay)) {
    char darkName[64];
    snprintf(darkName, sizeof(darkName), "%s_d.jpg", clockStr);
    captureAndSave(dayStr, darkName, dayKey, true);
  }
}

// ============================================================================
// 8. Wi-Fi 掃描與設定模式燈號
// ============================================================================

// 設定模式下快閃兩下、停 1 秒（亮 150 ms、滅 150 ms、亮 150 ms、滅 1000 ms，低電位亮）
void updateSetupLed() {
  unsigned long phase = millis() % 1450UL;
  bool ledOn = (phase < 150UL) || (phase >= 300UL && phase < 450UL);
  digitalWrite(21, ledOn ? LOW : HIGH);
}

// 掃描附近 Wi-Fi（去重、去空白、依訊號由強到弱，最多 20 個）
void scanWifiNetworks() {
  if (runMode == MODE_SETUP && !WiFi.isConnected()) {
    WiFi.disconnect(false, false);
    bgRetryActive = false;
  }

  int n = WiFi.scanNetworks();
  std::vector<ScannedNet> results;

  if (n > 0) {
    for (int i = 0; i < n; i++) {
      String ssid = WiFi.SSID(i);
      if (ssid.length() == 0) {
        continue;
      }
      int32_t rssi = WiFi.RSSI(i);
      bool encrypted = (WiFi.encryptionType(i) != WIFI_AUTH_OPEN);

      bool found = false;
      for (size_t j = 0; j < results.size(); j++) {
        if (results[j].ssid == ssid) {
          if (rssi > results[j].rssi) {
            results[j].rssi = rssi;
            results[j].encrypted = encrypted;
          }
          found = true;
          break;
        }
      }
      if (!found) {
        ScannedNet item;
        item.ssid = ssid;
        item.rssi = rssi;
        item.encrypted = encrypted;
        results.push_back(item);
      }
    }
  }
  WiFi.scanDelete();

  // 依訊號由強到弱排序
  for (size_t i = 0; i < results.size(); i++) {
    for (size_t j = i + 1; j < results.size(); j++) {
      if (results[j].rssi > results[i].rssi) {
        ScannedNet tmp = results[i];
        results[i] = results[j];
        results[j] = tmp;
      }
    }
  }

  if (results.size() > 20) {
    results.resize(20);
  }

  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
    scannedNets = results;
    xSemaphoreGive(stateMutex);
  } else {
    scannedNets = results;
  }
}

std::vector<ScannedNet> copyScannedNets() {
  std::vector<ScannedNet> copy;
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    copy = scannedNets;
    xSemaphoreGive(stateMutex);
  }
  return copy;
}

const char *rssiToBarsText(int32_t rssi) {
  if (rssi >= -55) return "4 格";
  if (rssi >= -67) return "3 格";
  if (rssi >= -78) return "2 格";
  return "1 格";
}

// ============================================================================
// 9. Improv Serial（支援 ESP Web Tools 瀏覽器直接設定 Wi-Fi）
// ============================================================================

void improvSendState(improv::State state) {
  uint8_t d[11] = {
    'I', 'M', 'P', 'R', 'O', 'V',
    improv::IMPROV_SERIAL_VERSION,
    improv::TYPE_CURRENT_STATE,
    1,
    (uint8_t)state,
    0
  };
  uint8_t sum = 0;
  for (int i = 0; i < 10; i++) {
    sum += d[i];
  }
  d[10] = sum;
  Serial.write(d, 11);
  Serial.write('\n');
}

void improvSendError(improv::Error err) {
  uint8_t d[11] = {
    'I', 'M', 'P', 'R', 'O', 'V',
    improv::IMPROV_SERIAL_VERSION,
    improv::TYPE_ERROR_STATE,
    1,
    (uint8_t)err,
    0
  };
  uint8_t sum = 0;
  for (int i = 0; i < 10; i++) {
    sum += d[i];
  }
  d[10] = sum;
  Serial.write(d, 11);
  Serial.write('\n');
}

void improvSendRpc(improv::Command cmd, const std::vector<String> &strs) {
  std::vector<uint8_t> payload = improv::build_rpc_response(cmd, strs, false);
  if (!payload.empty()) {
    payload.pop_back();  // 移除尾端保留給內層 checksum 的 0
  }
  std::vector<uint8_t> d = {
    'I', 'M', 'P', 'R', 'O', 'V',
    improv::IMPROV_SERIAL_VERSION,
    improv::TYPE_RPC_RESPONSE,
    (uint8_t)payload.size()
  };
  d.insert(d.end(), payload.begin(), payload.end());
  uint8_t sum = 0;
  for (uint8_t x : d) {
    sum += x;
  }
  d.push_back(sum);
  Serial.write(d.data(), d.size());
  Serial.write('\n');
}

void onImprovError(improv::Error e) {
  improvSendError(e);
}

bool onImprovCommand(improv::ImprovCommand cmd) {
  switch (cmd.command) {
    case improv::GET_CURRENT_STATE: {
      if (WiFi.status() == WL_CONNECTED) {
        improvSendState(improv::STATE_PROVISIONED);
        String url = String("http://") + WiFi.localIP().toString();
        improvSendRpc(improv::GET_CURRENT_STATE, {url});
      } else {
        improvSendState(improv::STATE_AUTHORIZED);
      }
      return true;
    }

    case improv::GET_DEVICE_INFO: {
      improvSendRpc(improv::GET_DEVICE_INFO, {
        String("SkyCam"),
        String(FW_VERSION),
        String("ESP32-S3"),
        String("SkyCam")
      });
      return true;
    }

    case improv::GET_WIFI_NETWORKS: {
      scanWifiNetworks();
      std::vector<ScannedNet> nets = copyScannedNets();
      for (size_t i = 0; i < nets.size(); i++) {
        improvSendRpc(improv::GET_WIFI_NETWORKS, {
          nets[i].ssid,
          String(nets[i].rssi),
          String(nets[i].encrypted ? "YES" : "NO")
        });
      }
      improvSendRpc(improv::GET_WIFI_NETWORKS, {});
      return true;
    }

    case improv::WIFI_SETTINGS: {
      improvSendState(improv::STATE_PROVISIONING);

      String newSsid(cmd.ssid.c_str());
      String newPass(cmd.password.c_str());

      bgRetryActive = false;
      if (runMode == MODE_SETUP) {
        WiFi.mode(WIFI_AP_STA);
      } else {
        WiFi.mode(WIFI_STA);
      }
      WiFi.disconnect(false, false);
      WiFi.begin(newSsid.c_str(), newPass.length() > 0 ? newPass.c_str() : nullptr);

      unsigned long startMs = millis();
      while (WiFi.status() != WL_CONNECTED && millis() - startMs < 20000UL) {
        if (runMode == MODE_SETUP) {
          dnsServer.processNextRequest();
          updateSetupLed();
        }
        delay(50);
      }

      if (WiFi.status() == WL_CONNECTED) {
        saveWifiSettings(newSsid, newPass);
        improvSendState(improv::STATE_PROVISIONED);
        String url = String("http://") + WiFi.localIP().toString();
        improvSendRpc(improv::WIFI_SETTINGS, {url});
        if (runMode == MODE_SETUP) {
          scheduleRestart(1000);
        }
        return true;
      }

      WiFi.disconnect(false, false);
      lastBgRetryStartMs = millis();
      improvSendError(improv::ERROR_UNABLE_TO_CONNECT);
      improvSendState(improv::STATE_AUTHORIZED);
      return false;
    }

    default:
      improvSendError(improv::ERROR_UNKNOWN_RPC);
      return false;
  }
}

void handleImprovSerial() {
  static uint8_t improvBuf[300];
  static size_t improvPos = 0;
  while (Serial.available() > 0) {
    uint8_t b = (uint8_t)Serial.read();
    if (improvPos >= sizeof(improvBuf)) {
      improvPos = 0;
    }
    if (improv::parse_improv_serial_byte(improvPos, b, improvBuf, onImprovCommand, onImprovError)) {
      // 第 8 個位元組是資料長度；收到「標頭 9 個＋資料＋檢查碼」的最後一個位元組時，
      // 這一包已經處理完，要從頭開始等下一包（不歸零的話，下一包的第一個字會被吃掉）
      bool packetDone = (improvPos >= 9) && (improvPos == (size_t)9 + improvBuf[8]);
      improvBuf[improvPos++] = b;
      if (packetDone) {
        improvPos = 0;
      }
    } else {
      improvPos = 0;
    }
  }
}

// ============================================================================
// 10. 網頁伺服器（esp_http_server）
// ============================================================================

// 依檔名由小到大排序（sizes 可為 nullptr，僅排序名稱陣列）
void sortPhotoArrays(char **names, unsigned long *sizes, size_t count) {
  for (size_t gap = count / 2; gap > 0; gap /= 2) {
    for (size_t i = gap; i < count; i++) {
      char *tempName = names[i];
      unsigned long tempSize = (sizes != nullptr) ? sizes[i] : 0;
      size_t j = i;
      while (j >= gap && strcmp(names[j - gap], tempName) > 0) {
        names[j] = names[j - gap];
        if (sizes != nullptr) {
          sizes[j] = sizes[j - gap];
        }
        j -= gap;
      }
      names[j] = tempName;
      if (sizes != nullptr) {
        sizes[j] = tempSize;
      }
    }
  }
}

void freePhotoArrays(char **names, unsigned long *sizes, size_t count) {
  if (names != nullptr) {
    for (size_t i = 0; i < count; i++) {
      free(names[i]);
    }
    free(names);
  }
  if (sizes != nullptr) {
    free(sizes);
  }
}

void setCorsHeader(httpd_req_t *req) {
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
}

esp_err_t sendTextResponse(httpd_req_t *req, const char *status, const char *contentType, const char *body) {
  setCorsHeader(req);
  httpd_resp_set_status(req, status);
  httpd_resp_set_type(req, contentType);
  return httpd_resp_send(req, body, HTTPD_RESP_USE_STRLEN);
}

esp_err_t sendRedirect(httpd_req_t *req, const char *location) {
  httpd_resp_set_status(req, "302 Found");
  httpd_resp_set_hdr(req, "Location", location);
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  httpd_resp_set_type(req, "text/plain; charset=utf-8");
  return httpd_resp_send(req, "正在導向設定頁...", HTTPD_RESP_USE_STRLEN);
}

bool isDigitChar(char c) {
  return c >= '0' && c <= '9';
}

bool parseStrictInt(const char *s, int *outVal) {
  if (s == nullptr || s[0] == '\0') {
    return false;
  }
  long val = 0;
  for (const char *p = s; *p != '\0'; p++) {
    if (!isDigitChar(*p)) {
      return false;
    }
    val = val * 10L + (long)(*p - '0');
    if (val > 100000L) {
      return false;
    }
  }
  *outVal = (int)val;
  return true;
}

int hexCharToInt(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

// URL 解碼（'+' 轉成空白，'%XX' 轉成對應位元組）
String urlDecode(const String &src) {
  String out;
  out.reserve(src.length());
  size_t len = src.length();
  for (size_t i = 0; i < len; i++) {
    char c = src[i];
    if (c == '+') {
      out += ' ';
    } else if (c == '%' && i + 2 < len) {
      int hi = hexCharToInt(src[i + 1]);
      int lo = hexCharToInt(src[i + 2]);
      if (hi >= 0 && lo >= 0) {
        out += (char)((hi << 4) | lo);
        i += 2;
      } else {
        out += c;
      }
    } else {
      out += c;
    }
  }
  return out;
}

// HTML 跳脫，避免 Wi-Fi 名稱含特殊符號破壞頁面
String escapeHtml(const String &src) {
  String out;
  out.reserve(src.length() + 16);
  for (size_t i = 0; i < src.length(); i++) {
    char c = src[i];
    switch (c) {
      case '&':  out += "&amp;";  break;
      case '<':  out += "&lt;";   break;
      case '>':  out += "&gt;";   break;
      case '"':  out += "&quot;"; break;
      case '\'': out += "&#39;";  break;
      default:   out += c;        break;
    }
  }
  return out;
}

// 安全檢查：日期必須剛好 8 位數字
bool isValidDay(const char *s) {
  if (s == nullptr || strlen(s) != 8) {
    return false;
  }
  for (size_t i = 0; i < 8; i++) {
    if (!isDigitChar(s[i])) {
      return false;
    }
  }
  return true;
}

// 安全檢查：檔名必須是「6 位數字 + 可選 _d + .jpg」
bool isValidPhotoName(const char *s) {
  if (s == nullptr) {
    return false;
  }
  size_t len = strlen(s);
  if (len != 10 && len != 12) {
    return false;
  }
  for (size_t i = 0; i < 6; i++) {
    if (!isDigitChar(s[i])) {
      return false;
    }
  }
  if (len == 10) {
    return strcmp(s + 6, ".jpg") == 0;
  }
  return strcmp(s + 6, "_d.jpg") == 0;
}

// 取得不含前導斜線的檔名指標
const char *baseNamePtr(const char *path) {
  if (path == nullptr) {
    return "";
  }
  const char *slash = strrchr(path, '/');
  return slash ? (slash + 1) : path;
}

// 將字串進行簡易 JSON 跳脫
String escapeJson(const char *src) {
  String out;
  if (src == nullptr) {
    return out;
  }
  for (const char *p = src; *p != '\0'; p++) {
    char c = *p;
    if (c == '"' || c == '\\') {
      out += '\\';
      out += c;
    } else if ((unsigned char)c >= 0x20) {
      out += c;
    }
  }
  return out;
}

// 從查詢字串讀取指定參數值
bool getQueryParam(httpd_req_t *req, const char *key, char *val, size_t valSize) {
  size_t qlen = httpd_req_get_url_query_len(req);
  if (qlen == 0) {
    return false;
  }
  char *qbuf = (char *)malloc(qlen + 1);
  if (qbuf == nullptr) {
    return false;
  }
  bool found = false;
  if (httpd_req_get_url_query_str(req, qbuf, qlen + 1) == ESP_OK) {
    if (httpd_query_key_value(qbuf, key, val, valSize) == ESP_OK) {
      found = true;
    }
  }
  free(qbuf);
  return found;
}

// 1. GET /
esp_err_t handleRoot(httpd_req_t *req) {
  if (runMode == MODE_SETUP) {
    return sendRedirect(req, "http://192.168.4.1/setup");
  }

  char timeStr[80] = "尚未同步時間";
  struct tm t = {};
  if (getLocalTimeNow(&t)) {
    snprintf(timeStr, sizeof(timeStr), "%04d-%02d-%02d %02d:%02d:%02d",
             t.tm_year + 1900, t.tm_mon + 1, t.tm_mday,
             t.tm_hour, t.tm_min, t.tm_sec);
  }

  int todayCount = 0;
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
    todayCount = shotsToday;
    xSemaphoreGive(stateMutex);
  }

  char sdStatus[96] = "未偵測到 SD 卡";
  if (sdOk && sdMutex != nullptr && xSemaphoreTake(sdMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    if (sdOk) {
      unsigned long long totalMb = SD.totalBytes() / (1024ULL * 1024ULL);
      unsigned long long usedMb  = SD.usedBytes() / (1024ULL * 1024ULL);
      snprintf(sdStatus, sizeof(sdStatus), "正常（已用 %llu MB / 共 %llu MB）", usedMb, totalMb);
    }
    xSemaphoreGive(sdMutex);
  }

  char wifiStatus[64] = "未連線";
  if (WiFi.isConnected()) {
    snprintf(wifiStatus, sizeof(wifiStatus), "已連線（%d dBm）", (int)WiFi.RSSI());
  }

  String html;
  html.reserve(1536);
  html += "<!DOCTYPE html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">";
  html += "<title>天空日記相機</title>";
  html += "<style>body{font-family:sans-serif;max-width:680px;margin:16px auto;padding:0 12px;line-height:1.6;}";
  html += "img{max-width:100%;height:auto;border-radius:8px;border:1px solid #ccc;}";
  html += ".nav a{display:inline-block;margin:4px 10px 4px 0;}</style></head><body>";
  html += "<h1>天空日記相機</h1><ul>";
  html += "<li>韌體版本：" + String(FW_VERSION) + "</li>";
  html += "<li>現在時間：" + String(timeStr) + "</li>";
  html += "<li>今天已拍張數：" + String(todayCount) + " 張</li>";
  html += "<li>SD 卡狀態：" + String(sdStatus) + "</li>";
  html += "<li>Wi-Fi 訊號：" + String(wifiStatus) + "</li>";
  html += "</ul>";
  html += "<p class=\"nav\">";
  html += "<a href=\"/days\">查看拍照日期列表 (/days)</a>";
  html += "<a href=\"/setup\">Wi-Fi 設定 (/setup)</a>";
  html += "<a href=\"/update\">韌體更新 (/update)</a>";
  html += "</p>";
  html += "<h2>即時畫面</h2>";
  html += "<p><img src=\"/capture\" alt=\"即時畫面\"></p>";
  html += "</body></html>";

  return sendTextResponse(req, "200 OK", "text/html; charset=utf-8", html.c_str());
}

// 2. GET /status
esp_err_t handleStatus(httpd_req_t *req) {
  bool synced = false;
  char timeStr[80] = "";
  struct tm t = {};
  if (getLocalTimeNow(&t)) {
    synced = true;
    snprintf(timeStr, sizeof(timeStr), "%04d-%02d-%02d %02d:%02d:%02d",
             t.tm_year + 1900, t.tm_mon + 1, t.tm_mday,
             t.tm_hour, t.tm_min, t.tm_sec);
  }

  unsigned long long uptimeSec = (unsigned long long)(esp_timer_get_time() / 1000000ULL);
  String ipStr = WiFi.isConnected() ? WiFi.localIP().toString() : String("");
  int rssi = WiFi.isConnected() ? (int)WiFi.RSSI() : 0;

  bool curSdOk = sdOk;
  unsigned long long sdTotalMb = 0;
  unsigned long long sdUsedMb  = 0;
  if (curSdOk && sdMutex != nullptr && xSemaphoreTake(sdMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    curSdOk = sdOk;
    if (curSdOk) {
      sdTotalMb = SD.totalBytes() / (1024ULL * 1024ULL);
      sdUsedMb  = SD.usedBytes() / (1024ULL * 1024ULL);
    }
    xSemaphoreGive(sdMutex);
  }

  int sToday = 0;
  int sTotal = 0;
  char fileCopy[48] = "";
  char errCopy[128] = "";
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
    sToday = shotsToday;
    sTotal = shotsTotal;
    snprintf(fileCopy, sizeof(fileCopy), "%s", lastFile);
    snprintf(errCopy, sizeof(errCopy), "%s", lastError);
    xSemaphoreGive(stateMutex);
  }

  const char *modeStr = (runMode == MODE_SETUP) ? "setup" : "normal";
  const char *apNameStr = (runMode == MODE_SETUP) ? apSsid.c_str() : "";

  String json;
  json.reserve(640);
  json += "{";
  json += "\"fw\":\"" + escapeJson(FW_VERSION) + "\",";
  json += "\"time\":\"" + String(timeStr) + "\",";
  json += "\"synced\":" + String(synced ? "true" : "false") + ",";
  json += "\"uptime_s\":" + String((unsigned long)uptimeSec) + ",";
  json += "\"ip\":\"" + escapeJson(ipStr.c_str()) + "\",";
  json += "\"rssi\":" + String(rssi) + ",";
  json += "\"sd_ok\":" + String(curSdOk ? "true" : "false") + ",";
  json += "\"sd_total_mb\":" + String((unsigned long)sdTotalMb) + ",";
  json += "\"sd_used_mb\":" + String((unsigned long)sdUsedMb) + ",";
  json += "\"shots_today\":" + String(sToday) + ",";
  json += "\"shots_total\":" + String(sTotal) + ",";
  json += "\"last_file\":\"" + escapeJson(fileCopy) + "\",";
  json += "\"last_error\":\"" + escapeJson(errCopy) + "\",";
  json += "\"sensor_pid\":" + String(sensorPid) + ",";
  json += "\"free_heap\":" + String((unsigned long)ESP.getFreeHeap()) + ",";
  json += "\"free_psram\":" + String((unsigned long)ESP.getFreePsram()) + ",";
  json += "\"mode\":\"" + String(modeStr) + "\",";
  json += "\"ap_ssid\":\"" + escapeJson(apNameStr) + "\"";
  json += "}";

  return sendTextResponse(req, "200 OK", "application/json; charset=utf-8", json.c_str());
}

// 3. GET /capture
esp_err_t handleCapture(httpd_req_t *req) {
  char val[16];
  bool dark = false;
  bool wantSave = false;

  if (getQueryParam(req, "dark", val, sizeof(val))) {
    dark = (strcmp(val, "1") == 0);
  }
  if (getQueryParam(req, "save", val, sizeof(val))) {
    wantSave = (strcmp(val, "1") == 0);
  }

  uint8_t *jpgBuf = nullptr;
  size_t jpgLen = 0;
  if (!takePhoto(dark, &jpgBuf, &jpgLen)) {
    return sendTextResponse(req, "503 Service Unavailable", "text/plain; charset=utf-8", "拍照失敗或鏡頭忙碌");
  }

  if (wantSave && sdOk) {
    struct tm t = {};
    if (getLocalTimeNow(&t)) {
      char dayStr[48];
      char clockStr[48];
      int dayKey = 0;
      formatDayAndClock(t, dayStr, sizeof(dayStr), clockStr, sizeof(clockStr), &dayKey);

      char fileName[64];
      snprintf(fileName, sizeof(fileName), dark ? "%s_d.jpg" : "%s.jpg", clockStr);

      char savedPath[48] = "";
      if (savePhotoToSD(dayStr, fileName, jpgBuf, jpgLen, savedPath, sizeof(savedPath))) {
        recordShotSuccess(dayKey, savedPath);
      }
    }
  }

  setCorsHeader(req);
  httpd_resp_set_type(req, "image/jpeg");
  esp_err_t res = httpd_resp_send(req, (const char *)jpgBuf, (ssize_t)jpgLen);
  free(jpgBuf);
  return res;
}

// 4. GET /days
esp_err_t handleDays(httpd_req_t *req) {
  if (!sdOk) {
    return sendTextResponse(req, "503 Service Unavailable", "application/json; charset=utf-8", "[]");
  }
  if (sdMutex == nullptr || xSemaphoreTake(sdMutex, pdMS_TO_TICKS(5000)) != pdTRUE) {
    return sendTextResponse(req, "503 Service Unavailable", "application/json; charset=utf-8", "[]");
  }

  char **days = nullptr;
  size_t count = 0;
  size_t capacity = 0;

  File root = SD.open("/");
  if (root && root.isDirectory()) {
    File entry = root.openNextFile();
    while (entry) {
      if (entry.isDirectory()) {
        const char *name = baseNamePtr(entry.name());
        if (isValidDay(name)) {
          if (count == capacity) {
            size_t newCap = (capacity == 0) ? 32 : capacity * 2;
            char **tmp = (char **)realloc(days, newCap * sizeof(char *));
            if (tmp == nullptr) {
              entry.close();
              break;
            }
            days = tmp;
            capacity = newCap;
          }
          char *dup = strdup(name);
          if (dup != nullptr) {
            days[count] = dup;
            count++;
          }
        }
      }
      entry.close();
      entry = root.openNextFile();
    }
    root.close();
  } else if (root) {
    root.close();
  }
  xSemaphoreGive(sdMutex);

  if (count > 1) {
    sortPhotoArrays(days, nullptr, count);
  }

  setCorsHeader(req);
  httpd_resp_set_type(req, "application/json; charset=utf-8");
  if (httpd_resp_send_chunk(req, "[", 1) != ESP_OK) {
    freePhotoArrays(days, nullptr, count);
    return ESP_FAIL;
  }

  for (size_t i = 0; i < count; i++) {
    char item[32];
    int n = snprintf(item, sizeof(item), "%s\"%s\"", (i > 0) ? "," : "", days[i]);
    if (n > 0 && httpd_resp_send_chunk(req, item, n) != ESP_OK) {
      freePhotoArrays(days, nullptr, count);
      return ESP_FAIL;
    }
  }

  freePhotoArrays(days, nullptr, count);
  if (httpd_resp_send_chunk(req, "]", 1) != ESP_OK) {
    return ESP_FAIL;
  }
  return httpd_resp_send_chunk(req, nullptr, 0);
}

// 5. GET /list?day=YYYYMMDD
esp_err_t handleList(httpd_req_t *req) {
  char day[16] = "";
  if (!getQueryParam(req, "day", day, sizeof(day)) || !isValidDay(day)) {
    return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8", "day 參數必須為 8 位數字");
  }

  if (!sdOk) {
    return sendTextResponse(req, "200 OK", "application/json; charset=utf-8", "[]");
  }
  if (sdMutex == nullptr || xSemaphoreTake(sdMutex, pdMS_TO_TICKS(5000)) != pdTRUE) {
    return sendTextResponse(req, "503 Service Unavailable", "application/json; charset=utf-8", "[]");
  }

  char **names = nullptr;
  unsigned long *sizes = nullptr;
  size_t count = 0;
  size_t capacity = 0;

  char dirPath[32];
  snprintf(dirPath, sizeof(dirPath), "/%s", day);

  File dir = SD.open(dirPath);
  if (dir && dir.isDirectory()) {
    File entry = dir.openNextFile();
    while (entry) {
      if (!entry.isDirectory()) {
        const char *name = baseNamePtr(entry.name());
        if (name[0] != '\0' && name[0] != '.') {
          if (count == capacity) {
            size_t newCap = (capacity == 0) ? 64 : capacity * 2;
            char **tmpNames = (char **)realloc(names, newCap * sizeof(char *));
            if (tmpNames == nullptr) {
              entry.close();
              break;
            }
            names = tmpNames;
            unsigned long *tmpSizes = (unsigned long *)realloc(sizes, newCap * sizeof(unsigned long));
            if (tmpSizes == nullptr) {
              entry.close();
              break;
            }
            sizes = tmpSizes;
            capacity = newCap;
          }
          char *dup = strdup(name);
          if (dup != nullptr) {
            names[count] = dup;
            sizes[count] = (unsigned long)entry.size();
            count++;
          }
        }
      }
      entry.close();
      entry = dir.openNextFile();
    }
    dir.close();
  } else if (dir) {
    dir.close();
  }
  xSemaphoreGive(sdMutex);

  if (count > 1) {
    sortPhotoArrays(names, sizes, count);
  }

  setCorsHeader(req);
  httpd_resp_set_type(req, "application/json; charset=utf-8");
  if (httpd_resp_send_chunk(req, "[", 1) != ESP_OK) {
    freePhotoArrays(names, sizes, count);
    return ESP_FAIL;
  }

  char chunkBuf[1024];
  size_t used = 0;

  for (size_t i = 0; i < count; i++) {
    String escaped = escapeJson(names[i]);
    char itemBuf[320];
    int itemLen = snprintf(itemBuf, sizeof(itemBuf), "%s{\"name\":\"%s\",\"size\":%lu}",
                           (i > 0) ? "," : "", escaped.c_str(), sizes[i]);
    if (itemLen <= 0 || (size_t)itemLen >= sizeof(itemBuf)) {
      continue;
    }

    if (used + (size_t)itemLen > sizeof(chunkBuf)) {
      if (httpd_resp_send_chunk(req, chunkBuf, (ssize_t)used) != ESP_OK) {
        freePhotoArrays(names, sizes, count);
        return ESP_FAIL;
      }
      used = 0;
    }
    memcpy(chunkBuf + used, itemBuf, (size_t)itemLen);
    used += (size_t)itemLen;
  }

  freePhotoArrays(names, sizes, count);

  if (used > 0) {
    if (httpd_resp_send_chunk(req, chunkBuf, (ssize_t)used) != ESP_OK) {
      return ESP_FAIL;
    }
  }

  if (httpd_resp_send_chunk(req, "]", 1) != ESP_OK) {
    return ESP_FAIL;
  }
  return httpd_resp_send_chunk(req, nullptr, 0);
}

// 6. GET /photo?day=YYYYMMDD&name=HHMMSS.jpg
esp_err_t handlePhoto(httpd_req_t *req) {
  char day[16]  = "";
  char name[24] = "";

  if (!getQueryParam(req, "day", day, sizeof(day)) || !isValidDay(day)) {
    return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8", "day 參數不合法");
  }
  if (!getQueryParam(req, "name", name, sizeof(name)) || !isValidPhotoName(name)) {
    return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8", "name 參數不合法");
  }

  if (!sdOk) {
    return sendTextResponse(req, "404 Not Found", "text/plain; charset=utf-8", "找不到 SD 卡或檔案");
  }

  uint8_t *readBuf = (uint8_t *)malloc(4096);
  if (readBuf == nullptr) {
    return sendTextResponse(req, "500 Internal Server Error", "text/plain; charset=utf-8", "記憶體不足");
  }

  if (sdMutex == nullptr || xSemaphoreTake(sdMutex, pdMS_TO_TICKS(5000)) != pdTRUE) {
    free(readBuf);
    return sendTextResponse(req, "503 Service Unavailable", "text/plain; charset=utf-8", "SD 卡忙碌中");
  }

  char fullPath[64];
  snprintf(fullPath, sizeof(fullPath), "/%s/%s", day, name);
  File file = SD.open(fullPath, FILE_READ);
  if (!file || file.isDirectory()) {
    if (file) {
      file.close();
    }
    xSemaphoreGive(sdMutex);
    free(readBuf);
    return sendTextResponse(req, "404 Not Found", "text/plain; charset=utf-8", "找不到指定的相片");
  }

  setCorsHeader(req);
  httpd_resp_set_type(req, "image/jpeg");

  esp_err_t res = ESP_OK;
  while (true) {
    size_t n = file.read(readBuf, 4096);
    if (n == 0) {
      break;
    }
    res = httpd_resp_send_chunk(req, (const char *)readBuf, (ssize_t)n);
    if (res != ESP_OK) {
      break;
    }
  }

  file.close();
  xSemaphoreGive(sdMutex);
  free(readBuf);

  if (res != ESP_OK) {
    return ESP_FAIL;
  }
  return httpd_resp_send_chunk(req, nullptr, 0);
}

// 產生 Wi-Fi 設定頁面（GET /setup 與 POST /save 錯誤時共用）
esp_err_t renderSetupPage(httpd_req_t *req, const char *status, const char *errorMsg) {
  std::vector<ScannedNet> nets = copyScannedNets();

  String html;
  html.reserve(2560);
  html += "<!DOCTYPE html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">";
  html += "<title>天空日記相機　Wi-Fi 設定</title>";
  html += "<style>";
  html += "body{font-family:sans-serif;max-width:480px;margin:20px auto;padding:0 14px;line-height:1.6;color:#222;}";
  html += "h1{font-size:1.4rem;}";
  html += "label{display:block;margin-top:12px;font-weight:bold;}";
  html += "select,input[type=text],input[type=password]{width:100%;box-sizing:border-box;padding:10px;margin-top:4px;font-size:1rem;border:1px solid #bbb;border-radius:6px;}";
  html += ".chk{margin-top:8px;font-weight:normal;}";
  html += "button{width:100%;margin-top:18px;padding:12px;font-size:1.05rem;background:#1a73e8;color:#fff;border:none;border-radius:6px;cursor:pointer;}";
  html += ".err{background:#fdecea;color:#b3261e;padding:10px;border-radius:6px;margin:12px 0;}";
  html += ".info{background:#eef4ff;color:#174ea6;padding:10px;border-radius:6px;margin:12px 0;}";
  html += ".hint{font-size:0.9rem;color:#666;margin-top:12px;}";
  html += ".links{margin-top:14px;display:flex;justify-content:space-between;}";
  html += "</style></head><body>";
  html += "<h1>天空日記相機　Wi-Fi 設定</h1>";

  if (runMode == MODE_NORMAL && WiFi.isConnected()) {
    html += "<div class=\"info\">目前連線的 Wi-Fi：" + escapeHtml(WiFi.SSID()) + "</div>";
  }
  if (errorMsg != nullptr && errorMsg[0] != '\0') {
    html += "<div class=\"err\">" + escapeHtml(String(errorMsg)) + "</div>";
  }

  html += "<form method=\"POST\" action=\"/save\">";
  html += "<label for=\"ssid\">選擇附近的 Wi-Fi</label>";
  html += "<select id=\"ssid\" name=\"ssid\">";
  html += "<option value=\"\">-- 請選擇 Wi-Fi --</option>";
  for (size_t i = 0; i < nets.size(); i++) {
    String escapedSsid = escapeHtml(nets[i].ssid);
    html += "<option value=\"" + escapedSsid + "\">";
    html += escapedSsid + "（訊號 " + String(rssiToBarsText(nets[i].rssi));
    html += nets[i].encrypted ? "，需密碼）" : "，無密碼）";
    html += "</option>";
  }
  html += "</select>";

  html += "<label for=\"ssid_manual\">手動輸入名稱</label>";
  html += "<input type=\"text\" id=\"ssid_manual\" name=\"ssid_manual\" maxlength=\"32\" placeholder=\"如果選單找不到，可直接輸入 Wi-Fi 名稱\">";

  html += "<label for=\"pass\">Wi-Fi 密碼</label>";
  html += "<input type=\"password\" id=\"pass\" name=\"pass\" maxlength=\"63\" placeholder=\"無密碼的網路可留空\">";
  html += "<label class=\"chk\"><input type=\"checkbox\" onclick=\"document.getElementById('pass').type=this.checked?'text':'password'\"> 顯示密碼</label>";

  html += "<button type=\"submit\">儲存並連線</button>";
  html += "</form>";

  html += "<div class=\"links\">";
  html += "<a href=\"/setup?rescan=1\">重新掃描</a>";
  if (runMode == MODE_NORMAL) {
    html += "<a href=\"/\">返回首頁</a>";
  }
  html += "</div>";
  html += "<p class=\"hint\">提醒：只支援 2.4 GHz 的 Wi-Fi。</p>";
  html += "</body></html>";

  return sendTextResponse(req, status, "text/html; charset=utf-8", html.c_str());
}

// 7. GET /setup
esp_err_t handleSetupGet(httpd_req_t *req) {
  char rescanVal[8] = "";
  bool wantRescan = getQueryParam(req, "rescan", rescanVal, sizeof(rescanVal)) && (strcmp(rescanVal, "1") == 0);

  bool isEmpty = false;
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
    isEmpty = scannedNets.empty();
    xSemaphoreGive(stateMutex);
  }

  if (wantRescan || isEmpty) {
    scanWifiNetworks();
  }

  return renderSetupPage(req, "200 OK", nullptr);
}

// 8. POST /save
esp_err_t handleSavePost(httpd_req_t *req) {
  size_t totalLen = req->content_len;
  if (totalLen == 0 || totalLen > 1024) {
    return renderSetupPage(req, "400 Bad Request", "表單資料無效或過長，請重新輸入。");
  }

  char bodyBuf[1025];
  size_t receivedTotal = 0;
  int timeoutRetries = 0;
  while (receivedTotal < totalLen) {
    int r = httpd_req_recv(req, bodyBuf + receivedTotal, totalLen - receivedTotal);
    if (r == HTTPD_SOCK_ERR_TIMEOUT) {
      timeoutRetries++;
      if (timeoutRetries > 10) {
        return renderSetupPage(req, "408 Request Timeout", "接收資料逾時，請再試一次。");
      }
      continue;
    }
    if (r <= 0) {
      return renderSetupPage(req, "400 Bad Request", "表單資料接收中斷，請再試一次。");
    }
    receivedTotal += (size_t)r;
  }
  bodyBuf[receivedTotal] = '\0';

  String ssidSelect;
  String ssidManual;
  String passVal;

  String bodyStr(bodyBuf);
  size_t start = 0;
  while (start <= bodyStr.length()) {
    int amp = bodyStr.indexOf('&', (unsigned int)start);
    String pair = (amp < 0) ? bodyStr.substring((unsigned int)start) : bodyStr.substring((unsigned int)start, (unsigned int)amp);
    int eq = pair.indexOf('=');
    if (eq > 0) {
      String key = urlDecode(pair.substring(0, (unsigned int)eq));
      String val = urlDecode(pair.substring((unsigned int)eq + 1));
      if (key == "ssid") {
        ssidSelect = val;
      } else if (key == "ssid_manual") {
        ssidManual = val;
      } else if (key == "pass") {
        passVal = val;
      }
    }
    if (amp < 0) {
      break;
    }
    start = (size_t)amp + 1;
  }

  String targetSsid = (ssidManual.length() > 0) ? ssidManual : ssidSelect;
  if (targetSsid.length() < 1 || targetSsid.length() > 32) {
    return renderSetupPage(req, "400 Bad Request", "Wi-Fi 名稱長度必須為 1～32 個位元組。");
  }
  if (passVal.length() != 0 && (passVal.length() < 8 || passVal.length() > 63)) {
    return renderSetupPage(req, "400 Bad Request", "Wi-Fi 密碼必須留空（無密碼），或是 8～63 個字元。");
  }

  if (!saveWifiSettings(targetSsid, passVal)) {
    return renderSetupPage(req, "500 Internal Server Error", "儲存設定失敗，請重新嘗試。");
  }

  String html;
  html.reserve(640);
  html += "<!DOCTYPE html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">";
  html += "<title>已儲存 Wi-Fi 設定</title>";
  html += "<style>body{font-family:sans-serif;max-width:480px;margin:24px auto;padding:0 14px;line-height:1.8;}</style>";
  html += "</head><body>";
  html += "<h1>Wi-Fi 設定已儲存</h1>";
  html += "<p>已儲存，相機正在重新啟動。請把手機連回家裡的 Wi-Fi，約 30 秒後開啟 http://skycam.local</p>";
  html += "</body></html>";

  esp_err_t res = sendTextResponse(req, "200 OK", "text/html; charset=utf-8", html.c_str());
  scheduleRestart(1500);
  return res;
}

// 9. GET /forget?confirm=yes
esp_err_t handleForget(httpd_req_t *req) {
  char confirmVal[16] = "";
  if (!getQueryParam(req, "confirm", confirmVal, sizeof(confirmVal)) || strcmp(confirmVal, "yes") != 0) {
    return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8",
                            "若要清除 Wi-Fi 設定，請使用 /forget?confirm=yes");
  }

  saveWifiSettings("", "");

  String html;
  html.reserve(512);
  html += "<!DOCTYPE html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">";
  html += "<title>已清除 Wi-Fi 設定</title></head><body>";
  html += "<h1>已清除 Wi-Fi 設定</h1>";
  html += "<p>相機正在重新啟動並進入設定模式，請用手機連線至 SkyCam 熱點重新設定。</p>";
  html += "</body></html>";

  esp_err_t res = sendTextResponse(req, "200 OK", "text/html; charset=utf-8", html.c_str());
  scheduleRestart(1500);
  return res;
}

// 10. GET /update
esp_err_t handleUpdateGet(httpd_req_t *req) {
  if (runMode == MODE_SETUP) {
    return sendRedirect(req, "http://192.168.4.1/setup");
  }

  bool needPass = (OTA_PASSWORD != nullptr && OTA_PASSWORD[0] != '\0');

  String html;
  html.reserve(2048);
  html += "<!DOCTYPE html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\">";
  html += "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">";
  html += "<title>韌體更新</title>";
  html += "<style>";
  html += "body{font-family:sans-serif;max-width:480px;margin:20px auto;padding:0 14px;line-height:1.6;}";
  html += "label{display:block;margin-top:12px;font-weight:bold;}";
  html += "input{width:100%;box-sizing:border-box;padding:10px;margin-top:6px;font-size:1rem;}";
  html += "button{width:100%;margin-top:16px;padding:12px;font-size:1.05rem;background:#1a73e8;color:#fff;border:none;border-radius:6px;cursor:pointer;}";
  html += "button:disabled{background:#9aa0a6;cursor:not-allowed;}";
  html += "#msg{margin-top:14px;padding:10px;border-radius:6px;background:#f5f5f5;}";
  html += "</style></head><body>";
  html += "<h1>韌體更新</h1>";
  html += "<p>目前韌體版本：" + String(FW_VERSION) + "</p>";
  html += "<label for=\"fwFile\">選擇韌體檔案（.bin）</label>";
  html += "<input type=\"file\" id=\"fwFile\" accept=\".bin\">";
  if (needPass) {
    html += "<label for=\"otaPass\">更新密碼</label>";
    html += "<input type=\"password\" id=\"otaPass\" placeholder=\"請輸入更新密碼\">";
  }
  html += "<button type=\"button\" id=\"btnUpload\" onclick=\"uploadFw()\">開始更新</button>";
  html += "<div id=\"msg\">請選擇要上傳的 .bin 韌體檔案。</div>";
  html += "<p><a href=\"/\">返回首頁</a></p>";
  html += "<script>";
  html += "async function uploadFw(){";
  html += "const f=document.getElementById('fwFile').files[0];";
  html += "const m=document.getElementById('msg');";
  html += "const b=document.getElementById('btnUpload');";
  html += "if(!f){m.textContent='請先選擇一個 .bin 檔案。';return;}";
  html += "const pEl=document.getElementById('otaPass');";
  html += "const hdr={'Content-Type':'application/octet-stream'};";
  html += "if(pEl){hdr['X-OTA-Password']=pEl.value;}";
  html += "b.disabled=true;m.textContent='上傳中…';";
  html += "try{";
  html += "const r=await fetch('/update',{method:'POST',headers:hdr,body:f});";
  html += "const t=await r.text();";
  html += "if(r.ok){m.textContent='更新成功，相機重新啟動中';}";
  html += "else{m.textContent='更新失敗：'+t;b.disabled=false;}";
  html += "}catch(e){m.textContent='上傳發生錯誤：'+e;b.disabled=false;}";
  html += "}";
  html += "</script></body></html>";

  return sendTextResponse(req, "200 OK", "text/html; charset=utf-8", html.c_str());
}

// 11. POST /update
esp_err_t handleUpdatePost(httpd_req_t *req) {
  if (runMode == MODE_SETUP) {
    return sendTextResponse(req, "503 Service Unavailable", "text/plain; charset=utf-8",
                            "設定模式下不支援網頁韌體更新");
  }

  if (OTA_PASSWORD != nullptr && OTA_PASSWORD[0] != '\0') {
    char passBuf[128] = "";
    size_t hdrLen = httpd_req_get_hdr_value_len(req, "X-OTA-Password");
    if (hdrLen == 0 || hdrLen >= sizeof(passBuf) ||
        httpd_req_get_hdr_value_str(req, "X-OTA-Password", passBuf, sizeof(passBuf)) != ESP_OK ||
        strcmp(passBuf, OTA_PASSWORD) != 0) {
      return sendTextResponse(req, "403 Forbidden", "text/plain; charset=utf-8", "更新密碼錯誤");
    }
  }

  const size_t MAX_OTA_SIZE = 3342336;
  if (req->content_len == 0 || req->content_len > MAX_OTA_SIZE) {
    return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8",
                            "韌體檔案大小不合法（必須介於 1～3342336 位元組）");
  }

  if (otaBusy) {
    return sendTextResponse(req, "503 Service Unavailable", "text/plain; charset=utf-8",
                            "已有其他韌體更新正在進行中");
  }

  otaBusy = true;
  Serial.printf("開始網頁韌體更新（大小：%u 位元組）\n", (unsigned)req->content_len);

  if (!Update.begin(req->content_len)) {
    const char *errStr = Update.errorString();
    otaBusy = false;
    Serial.printf("Update.begin 失敗：%s\n", errStr);
    return sendTextResponse(req, "500 Internal Server Error", "text/plain; charset=utf-8", errStr);
  }

  uint8_t *buf = (uint8_t *)malloc(4096);
  if (buf == nullptr) {
    Update.abort();
    otaBusy = false;
    return sendTextResponse(req, "500 Internal Server Error", "text/plain; charset=utf-8", "記憶體不足");
  }

  size_t remaining = req->content_len;
  while (remaining > 0) {
    size_t toRead = (remaining < 4096) ? remaining : 4096;
    int received = httpd_req_recv(req, (char *)buf, toRead);
    if (received == HTTPD_SOCK_ERR_TIMEOUT) {
      continue;
    }
    if (received <= 0) {
      free(buf);
      Update.abort();
      otaBusy = false;
      Serial.println("網頁韌體更新接收資料失敗");
      return sendTextResponse(req, "500 Internal Server Error", "text/plain; charset=utf-8",
                              "接收韌體資料中斷");
    }

    size_t written = Update.write(buf, (size_t)received);
    if (written != (size_t)received) {
      const char *errStr = Update.errorString();
      free(buf);
      Update.abort();
      otaBusy = false;
      Serial.printf("Update.write 失敗：%s\n", errStr);
      return sendTextResponse(req, "500 Internal Server Error", "text/plain; charset=utf-8", errStr);
    }
    remaining -= (size_t)received;
  }
  free(buf);

  if (!Update.end(true)) {
    const char *errStr = Update.errorString();
    otaBusy = false;
    Serial.printf("Update.end 失敗：%s\n", errStr);
    return sendTextResponse(req, "500 Internal Server Error", "text/plain; charset=utf-8", errStr);
  }

  Serial.println("網頁韌體更新成功，1 秒後重新啟動");
  esp_err_t res = sendTextResponse(req, "200 OK", "text/plain; charset=utf-8", "OK");
  scheduleRestart(1000);
  return res;
}

// 12. GET /config
esp_err_t handleConfig(httpd_req_t *req) {
  char flipStr[16] = "";
  char daecStr[16] = "";
  bool hasFlip = getQueryParam(req, "flip", flipStr, sizeof(flipStr));
  bool hasDaec = getQueryParam(req, "dark_aec", daecStr, sizeof(daecStr));
  char txpStr[16] = "";
  if (getQueryParam(req, "txpower", txpStr, sizeof(txpStr))) {
    int parsedTxp = 0;
    if (!parseStrictInt(txpStr, &parsedTxp) || parsedTxp < 2 || parsedTxp > 20) {
      return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8",
                              "txpower 參數必須為 2～20 的整數（dBm）");
    }
    cfgTxPower = parsedTxp;
    saveTxPower(parsedTxp);
    applyTxPower();
  }

  bool newFlip = cfgFlip180;
  int newDaec = cfgDarkAec;
  if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
    newFlip = cfgFlip180;
    newDaec = cfgDarkAec;
    xSemaphoreGive(stateMutex);
  }

  if (hasFlip) {
    if (strcmp(flipStr, "0") == 0) {
      newFlip = false;
    } else if (strcmp(flipStr, "1") == 0) {
      newFlip = true;
    } else {
      return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8",
                              "flip 參數必須為 0 或 1");
    }
  }

  if (hasDaec) {
    int parsed = 0;
    if (!parseStrictInt(daecStr, &parsed) || parsed < 1 || parsed > 1200) {
      return sendTextResponse(req, "400 Bad Request", "text/plain; charset=utf-8",
                              "dark_aec 參數必須為 1～1200 的整數");
    }
    newDaec = parsed;
  }

  if (hasFlip || hasDaec) {
    if (stateMutex != nullptr && xSemaphoreTake(stateMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
      cfgFlip180 = newFlip;
      cfgDarkAec = newDaec;
      xSemaphoreGive(stateMutex);
    } else {
      cfgFlip180 = newFlip;
      cfgDarkAec = newDaec;
    }

    saveCameraSettings(newFlip, newDaec);

    if (hasFlip && cameraOk) {
      if (cameraMutex != nullptr && xSemaphoreTake(cameraMutex, pdMS_TO_TICKS(5000)) == pdTRUE) {
        sensor_t *s = esp_camera_sensor_get();
        applySensorFlip(s, newFlip);
        xSemaphoreGive(cameraMutex);
      }
    }
  }

  char jsonBuf[128];
  snprintf(jsonBuf, sizeof(jsonBuf), "{\"flip\":%s,\"dark_aec\":%d,\"txpower\":%d}",
           newFlip ? "true" : "false", newDaec, (int)cfgTxPower);
  return sendTextResponse(req, "200 OK", "application/json; charset=utf-8", jsonBuf);
}

// 13. GET /*（未登記路徑；設定模式導向 captive portal 設定頁）
esp_err_t handleWildcard(httpd_req_t *req) {
  if (runMode == MODE_SETUP) {
    return sendRedirect(req, "http://192.168.4.1/setup");
  }
  return sendTextResponse(req, "404 Not Found", "text/plain; charset=utf-8", "找不到指定的頁面");
}

void registerRoute(const char *path, httpd_method_t method, esp_err_t (*handler)(httpd_req_t *)) {
  httpd_uri_t uri = {};
  uri.uri     = path;
  uri.method  = method;
  uri.handler = handler;
  httpd_register_uri_handler(httpServer, &uri);
}

void startWebServer() {
  httpd_config_t config    = HTTPD_DEFAULT_CONFIG();
  config.server_port       = 80;
  config.max_uri_handlers  = 20;
  config.uri_match_fn      = httpd_uri_match_wildcard;
  config.recv_wait_timeout = 30;
  config.send_wait_timeout = 30;   // 訊號不好時傳一張照片可能要比較久，預設 5 秒太短
  config.lru_purge_enable  = true;
  config.stack_size        = 12288;

  if (httpd_start(&httpServer, &config) != ESP_OK) {
    Serial.println("網頁伺服器啟動失敗");
    setLastError("網頁伺服器啟動失敗");
    return;
  }

  registerRoute("/", HTTP_GET, handleRoot);
  registerRoute("/status", HTTP_GET, handleStatus);
  registerRoute("/capture", HTTP_GET, handleCapture);
  registerRoute("/days", HTTP_GET, handleDays);
  registerRoute("/list", HTTP_GET, handleList);
  registerRoute("/photo", HTTP_GET, handlePhoto);
  registerRoute("/setup", HTTP_GET, handleSetupGet);
  registerRoute("/save", HTTP_POST, handleSavePost);
  registerRoute("/forget", HTTP_GET, handleForget);
  registerRoute("/update", HTTP_GET, handleUpdateGet);
  registerRoute("/update", HTTP_POST, handleUpdatePost);
  registerRoute("/config", HTTP_GET, handleConfig);
  registerRoute("/*", HTTP_GET, handleWildcard);

  Serial.println("網頁伺服器已啟動（連接埠 80）");
}

// ============================================================================
// 11. 網路、OTA、模式啟動與 loop()
// ============================================================================

void startOtaAndMdnsIfReady() {
  if (runMode != MODE_NORMAL || otaStarted || !WiFi.isConnected()) {
    return;
  }

  ArduinoOTA.setHostname(MDNS_HOST);
  if (OTA_PASSWORD != nullptr && OTA_PASSWORD[0] != '\0') {
    ArduinoOTA.setPassword(OTA_PASSWORD);
  }
  ArduinoOTA.onStart([]() {
    otaBusy = true;
    Serial.println("開始進行 ArduinoOTA 韌體更新（暫停排程拍照）...");
  });
  ArduinoOTA.onEnd([]() {
    Serial.println("\nArduinoOTA 更新完成，即將重新啟動");
  });
  ArduinoOTA.onError([](ota_error_t error) {
    otaBusy = false;
    Serial.printf("ArduinoOTA 更新發生錯誤，代碼：%u\n", (unsigned)error);
  });

  // ArduinoOTA.begin() 會自動啟動 mDNS，接著直接登記 HTTP 服務即可
  ArduinoOTA.begin();
  MDNS.addService("http", "tcp", 80);
  otaStarted = true;
  mdnsStarted = true;
}

bool connectWiFiSta(unsigned long timeoutMs) {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.setHostname(MDNS_HOST);
  WiFi.begin(wifiSsid.c_str(), wifiPass.length() > 0 ? wifiPass.c_str() : nullptr);
  applyTxPower();

  Serial.printf("正在連線 Wi-Fi（%s）", wifiSsid.c_str());
  unsigned long startMs = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startMs < timeoutMs) {
    delay(250);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.isConnected()) {
    wasWifiConnected = true;
    Serial.print("Wi-Fi 已連線，IP 位址：");
    Serial.println(WiFi.localIP());
    Serial.printf("瀏覽器網址：http://%s.local\n", MDNS_HOST);
    return true;
  }
  return false;
}

void enterSetupMode() {
  runMode = MODE_SETUP;
  sdOk = false;

  // 設定模式未掛載 SD 卡，使用 GPIO21 橘色 LED 提醒使用者連線設定
  pinMode(21, OUTPUT);
  digitalWrite(21, HIGH);

  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);
  WiFi.disconnect(false, false);
  delay(100);

  uint8_t mac[6] = {};
  WiFi.macAddress(mac);
  char apBuf[24];
  snprintf(apBuf, sizeof(apBuf), "SkyCam-%02X%02X", (unsigned)mac[4], (unsigned)mac[5]);
  apSsid = String(apBuf);

  // 先掃描一次附近 Wi-Fi 並保存結果
  scanWifiNetworks();

  IPAddress apIP(192, 168, 4, 1);
  IPAddress apMask(255, 255, 255, 0);
  WiFi.softAPConfig(apIP, apIP, apMask);
  WiFi.softAP(apSsid.c_str());

  dnsServer.setErrorReplyCode(DNSReplyCode::NoError);
  dnsServer.start(53, "*", WiFi.softAPIP());

  startWebServer();

  bgRetryActive = false;
  lastBgRetryStartMs = millis();

  Serial.println("進入 Wi-Fi 設定模式");
  Serial.printf("請用手機連線至熱點：%s（無密碼）\n", apSsid.c_str());
  Serial.println("若未自動跳出設定畫面，請在瀏覽器開啟：http://192.168.4.1/setup");
}

// 設定模式下若有已存帳密，每 120 秒背景試連一次（最多等 15 秒），連上即重啟回一般模式
void runSetupBgRetry() {
  if (!hasSavedWifi) {
    return;
  }
  unsigned long nowMs = millis();
  if (!bgRetryActive) {
    if (nowMs - lastBgRetryStartMs >= 120000UL) {
      lastBgRetryStartMs = nowMs;
      bgRetryBeginMs = nowMs;
      bgRetryActive = true;
      Serial.printf("背景嘗試重新連線原本的 Wi-Fi（%s）...\n", wifiSsid.c_str());
      WiFi.begin(wifiSsid.c_str(), wifiPass.length() > 0 ? wifiPass.c_str() : nullptr);
    }
    return;
  }

  if (WiFi.status() == WL_CONNECTED) {
    bgRetryActive = false;
    Serial.println("背景重連原本的 Wi-Fi 成功，即將重新啟動進入一般模式");
    scheduleRestart(200);
    return;
  }

  if (nowMs - bgRetryBeginMs >= 15000UL) {
    bgRetryActive = false;
    WiFi.disconnect(false, false);
    Serial.println("背景重連逾時，繼續維持設定模式");
  }
}

void monitorWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    wifiDisconnectSinceMs = 0;
    if (!wasWifiConnected) {
      wasWifiConnected = true;
      startOtaAndMdnsIfReady();
      Serial.print("Wi-Fi 已重新連線，IP 位址：");
      Serial.println(WiFi.localIP());
      Serial.printf("瀏覽器網址：http://%s.local\n", MDNS_HOST);
    }
    return;
  }

  wasWifiConnected = false;
  unsigned long nowMs = millis();
  if (wifiDisconnectSinceMs == 0) {
    wifiDisconnectSinceMs = nowMs;
  } else if (nowMs - wifiDisconnectSinceMs >= 60000UL && nowMs - lastWifiReconnectMs >= 60000UL) {
    lastWifiReconnectMs = nowMs;
    Serial.println("Wi-Fi 斷線超過 60 秒，嘗試重新連線...");
    WiFi.reconnect();
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.printf("\n=== 天空日記相機 v%s 啟動中 ===\n", FW_VERSION);

  cameraMutex = xSemaphoreCreateMutex();
  sdMutex     = xSemaphoreCreateMutex();
  stateMutex  = xSemaphoreCreateMutex();

  loadSettings();
  loadTxPower();
  cameraOk = initCamera();

  if (!hasSavedWifi) {
    Serial.println("尚未設定 Wi-Fi 帳密，將進入設定模式");
    enterSetupMode();
    return;
  }

  if (connectWiFiSta(25000UL)) {
    runMode = MODE_NORMAL;
    initSD();
    initTime();
    startOtaAndMdnsIfReady();
    startWebServer();
  } else {
    Serial.println("25 秒內無法連上已保存的 Wi-Fi，改進入設定模式（並定時背景重試）");
    enterSetupMode();
  }
}

void loop() {
  checkPendingRestart();

  if (runMode == MODE_NORMAL) {
    monitorWiFi();
    retrySDIfNeeded();
    if (!otaBusy) {
      runScheduler();
    }
    if (otaStarted) {
      ArduinoOTA.handle();
    }
    handleImprovSerial();
    delay(20);
  } else {
    dnsServer.processNextRequest();
    updateSetupLed();
    runSetupBgRetry();
    handleImprovSerial();
    delay(10);
  }
}
