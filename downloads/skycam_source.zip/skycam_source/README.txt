天空日記相機 skycam 原始程式（Arduino，XIAO ESP32-S3 Sense）

1. 用 Arduino IDE 2 開啟 skycam/skycam.ino；開發板管理員安裝 esp32 by Espressif Systems 3.x。
2. 工具 > 開發板選 XIAO_ESP32S3；工具 > PSRAM 選 OPI PSRAM；工具 > USB Mode 選 Hardware CDC and JTAG。
3. 上傳。Wi-Fi 不用寫在程式裡：第一次開機用手機連 SkyCam-XXXX 熱點設定。
   （想預先寫好也可以：把 secrets.h.example 複製成 secrets.h 填入。secrets.h 不要分享給別人。）

improv.h／improv.cpp 來自 Improv Wi-Fi 官方 C++ SDK（Apache-2.0，見 IMPROV_LICENSE.txt）。
